package busreservationsystem2;

import java.util.Scanner;
import java.util.*;

class CustNode {
    String name;
    int mobile;
    String email;
    String city;
    int age;
    CustNode next;  // Link to next customer node
}

class BusNode {
    int bCode;
    int totseats;
    String start;
    String end;
    int time; // Represents time or distance for this bus route
    int fare;
    BusNode next;  // Link to next bus node
}


class ResNode {
    int mobile;
    int bcode;
    int seatno;
    ResNode next;  // Link to next reservation node
}

class WaitNode {
    int mobile;
    int bcode;
    WaitNode next;  // Link to next waiting list node
}

public class BusReservationSystem2 {
    CustNode chead, ctail;
    BusNode bhead, btail;
    ResNode rhead, rtail;
    WaitNode whead, wtail;

    public void init() {
        chead = null;
        ctail = null;
        bhead = null;
        btail = null;
        rhead = null;
        rtail = null;
        whead = null;
        wtail = null;
        System.out.println("System Initialized.");
    }

    public void addCustomer() {
    Scanner obj = new Scanner(System.in);
    System.out.println("    ");
    System.out.println("REGISTER CUSTOMER");
    System.out.println("***********************************");
    System.out.print("Name: ");
    String name = obj.next();
    System.out.print("Mobile No: ");
    int mobile = obj.nextInt();  
    System.out.print("Email ID:\n");
    String email = obj.next();
    System.out.print("City:\n");
    String city = obj.next();
    System.out.print("Age:\n");
    int age = obj.nextInt();
    CustNode p = new CustNode();
    p.name = name;
    p.mobile = mobile;
    p.email = email;
    p.city = city;
    p.age = age;
    if (chead == null) { // empty list
        chead = p;
        ctail = p;
        ctail.next = null;
    } else { // not empty
        ctail.next = p;
        ctail = p;
        ctail.next = null;
    }
    System.out.println("     ");
    System.out.println("Customer Registered!");
}
    public void addBus() {
        Scanner obj = new Scanner(System.in);
        System.out.println("\nREGISTER BUS");
        System.out.println("***********************");
        System.out.print("Bus Number: ");
        int bCode = obj.nextInt();
        System.out.print("Total Seats: ");
        int totseats = obj.nextInt();
        System.out.print("Starting Point: ");
        String start = obj.next();
        System.out.print("Ending Point: ");
        String end = obj.next();
        System.out.print("Starting Time: ");
        int time = obj.nextInt();
        System.out.print("Fare: ");
        int fare = obj.nextInt();
        BusNode p = new BusNode();
        p.bCode = bCode;
        p.totseats = totseats;
        p.start = start;
        p.end = end;
        p.time = time;
        p.fare = fare;
        if (bhead == null) {
            bhead = p;
            btail = p;
        } else {
            btail.next = p;
            btail = p;
        }
        btail.next = null;
        System.out.println("\nBus Registered Successfully!");
    }
    
    public void findShortestPath(String startCity, String endCity) {
    // Initialize data structures
    Map<String, Integer> distances = new HashMap<>();
    Map<String, String> previousNodes = new HashMap<>();
    Set<String> unvisited = new HashSet<>();
    
    // PriorityQueue to get the city with the smallest distance
    PriorityQueue<String> pq = new PriorityQueue<>(Comparator.comparingInt(distances::get));
    
    // Populate the graph with buses
    BusNode p = bhead;
    while (p != null) {
        // Set all distances to infinity initially
        distances.put(p.start, Integer.MAX_VALUE);
        distances.put(p.end, Integer.MAX_VALUE);
        unvisited.add(p.start);
        unvisited.add(p.end);
        p = p.next;
    }
    
    // Set the distance for the starting city to 0
    distances.put(startCity, 0);
    pq.add(startCity);

    while (!pq.isEmpty()) {
        // Get the city with the smallest known distance
        String currentCity = pq.poll();

        // Remove the city from unvisited
        unvisited.remove(currentCity);

        // Update distances for neighbors
        BusNode bus = bhead;
        while (bus != null) {
            if (bus.start.equals(currentCity)) {
                int newDist = distances.get(currentCity) + bus.time;
                if (newDist < distances.get(bus.end)) {
                    distances.put(bus.end, newDist);
                    previousNodes.put(bus.end, currentCity);
                    pq.add(bus.end);
                }
            }
            bus = bus.next;
        }
    }

    // Print the shortest path
    if (distances.get(endCity) == Integer.MAX_VALUE) {
        System.out.println("No path found from " + startCity + " to " + endCity);
    } else {
        System.out.println("Shortest path from " + startCity + " to " + endCity + ":");
        String path = endCity;
        while (previousNodes.containsKey(path)) {
            path = previousNodes.get(path) + " -> " + path;
        }
        System.out.println(path);
        System.out.println("Total time: " + distances.get(endCity));
    }


}

    public void searchBus() {
        Scanner obj = new Scanner(System.in);
        System.out.println("\nEnter the Bus Code to Search: ");
        int bCode = obj.nextInt();
        BusNode p = bhead;

        while (p != null) {
            if (bCode == p.bCode) {
                System.out.println("Total Seats: " + p.totseats);
                System.out.println("Starting Point: " + p.start);
                System.out.println("Ending Point: " + p.end);
                System.out.println("Starting Time: " + p.time);
                System.out.println("Fare: " + p.fare);
                return;
            }
            p = p.next;
        }
        System.out.println("\nBus Not Found!");
    }
    
    public void displayCustomers() {
        System.out.println("\nLIST OF CUSTOMERS");
        System.out.println("******************************");
        CustNode p = chead;
        while (p != null) {
            System.out.println(p.name + "  " + p.mobile + "  " + p.email + "  " +  p.city + "  " + p.age);
            p = p.next;
        }
    }
    
    public void sortCustomersByAge() {
    if (chead == null || chead.next == null) {
        System.out.println("\nNo customers to sort or only one customer exists.");
        return; // No sorting needed for empty or single-node list
    }

    boolean swapped;
    do {
        swapped = false;
        CustNode current = chead;
        CustNode prev = null;

        while (current.next != null) {
            if (current.age > current.next.age) {
                // Swap nodes
                if (prev == null) { // Swapping head node
                    CustNode temp = current.next;
                    current.next = temp.next;
                    temp.next = current;
                    chead = temp;
                } else { // Swapping intermediate nodes
                    CustNode temp = current.next;
                    current.next = temp.next;
                    temp.next = current;
                    prev.next = temp;
                }
                swapped = true;
            }
            prev = current;
            current = current.next;
        }
    } while (swapped);

    System.out.println("\nCustomers sorted by age successfully!");
}
    
    public void reserveSeat(){
        Scanner obj = new Scanner (System.in);
        System.out.println("    ");
        System.out.print("Enter Mobile Number: ");
        int mobile = obj.nextInt();
        CustNode p = chead;
        boolean found = false;
        while (p!=null)
        {
            if (mobile == p.mobile)
            {
                System.out.println("   ");
                System.out.println("Name: " + p.name);
                System.out.println("Email:   " + p.email);
                System.out.println("City   " + p.city);
                System.out.println("Age   " + p.age);
                found = true;
                break;
            }
            else
            {
                p = p.next;
                
            }
        }
        if (found == false)
        {
            System.out.println("   ");
            System.out.println("CUSTOMER NOT FOUND!!!");
            System.out.println("*********************************");
            return;
            
        }
        System.out.println("   ");
        System.out.println("ENTER BUS CODE AS SEARCH KEY");
        int bcode = obj.nextInt();
        BusNode q = bhead;
        found = false;
        while (q!=null)
        {
            if (bcode == q.bCode)
            {
                System.out.println("    ");
                System.out.println("Total Seats;" +q.totseats);
                System.out.println("Starting Point:" + q.start);
                System.out.println("Ending Point: " + q.end);
                System.out.println("Starting Time: " + q.time);
                System.out.println("Fare: " + q.fare);
                
                found = true;
                break;
                
                
                
            }
            else
            {
                q = q.next;
            }
        }
        if (found==false)
        {
            System.out.println("   ");
            System.out.println("***********************************");
            System.out.println("BUS NOT FOUND!");
            return;
                
        }
        if (q.totseats==0)
        {
            System.out.println("   ");
            System.out.println("***********************************");
            System.out.println("SEATS UNAVAILABlE");
            WaitNode w = new WaitNode();
            w.mobile = p.mobile;
            w.bcode = q.bCode;
            System.out.println("   ");
            System.out.println("***********************************");
            System.out.println("CUSTOMER MOVED TO WAITING LIST");
            if (whead == null)
            {
                whead = w;
                wtail = w;
                wtail.next = null;
            }
            else
            {
                wtail.next = w;
                wtail = w;
                wtail.next = null;
            }
           
            
        }
        else
        {
            ResNode r = new ResNode();
            r.mobile = p.mobile;
            r.bcode = q.bCode;
            r.seatno = q.totseats;
            System.out.println("   ");
            System.out.println("************MESSAGE***********************");
            System.out.println("Reservation created for: " + p.name);
            System.out.println("Email: " + p.email);
            System.out.println("BUS Code: " + q.bCode);
            System.out.println("From: " + q.start + "to" + q.end);
            System.out.println("Starting Time: " + q.time);
            System.out.println("Fare: " + q.fare);
            System.out.println("Seat No: " + q.totseats);
            
            q.totseats = q.totseats - 1;
            
            if (rhead == null)
            {
                rhead = r;
                rtail = r;
                rtail.next = null;
                
            }
            else
            {
                rtail.next = r;
                rtail = r;
                rtail.next = null;
            }
        }
        
    }
    
    public void displayReservations()
{
    System.out.println(" ");
    System.out.println("LIST OF RESERVATIONS");
    System.out.println("********************");
    ResNode p = rhead;
    while (p != null)
    {
        System.out.println(p.mobile + " " + p.bcode + " " + p.seatno);
        p = p.next;
    }
} //end display reservations

public void cancelReservation() //delete reservation
{
    CustNode c;
    WaitNode w;
    ResNode p, q;
    BusNode s = bhead;
    p = rhead;
    q = null;
    w = whead;
    c = chead;
    Scanner obj = new Scanner(System.in);
    System.out.println(" ");
    System.out.println("********************");
    System.out.print("Enter Mobile Number as Search Key ");
    int mobile = obj.nextInt();
    while (p != null)
    {
        if (mobile == p.mobile) //match
        {
            if (q == null) //first node
                rhead = p.next;
            else //some other node
                q.next = p.next;
            System.out.println(" ");
            System.out.println("********************");
            System.out.println("Reservation deleted for " + p.mobile);
            s.totseats = s.totseats + 1;
            System.out.println("********************");
            System.out.println("Total seats available now: " + s.totseats);
            if (w == null)
                return;
            else
            {
                System.out.println(" ");
                System.out.println(s.bCode + " has available seats. The next in line is " + c.name + " " + w.mobile);
                System.out.println("********************");
            }
            return;
        }
        else
        {
            q = p;
            p = p.next;
        }
    } //end while
    System.out.println(" ");
    System.out.println("********************");
    System.out.println("Search key not found");
} //end cancel

public void sortReservationsBySeatNumber() {
    if (rhead == null || rhead.next == null) {
        System.out.println("\nNo reservations to sort or only one reservation exists.");
        return; // No sorting needed for empty or single-node list
    }

    boolean swapped;
    do {
        swapped = false;
        ResNode current = rhead;
        ResNode prev = null;

        while (current.next != null) {
            if (current.seatno > current.next.seatno) {
                // Swap nodes
                if (prev == null) { // Swapping head node
                    ResNode temp = current.next;
                    current.next = temp.next;
                    temp.next = current;
                    rhead = temp;
                } else { // Swapping intermediate nodes
                    ResNode temp = current.next;
                    current.next = temp.next;
                    temp.next = current;
                    prev.next = temp;
                }
                swapped = true;
            }
            prev = current;
            current = current.next;
        }
    } while (swapped);

    System.out.println("\nReservations sorted by seat number successfully!");
}

    


    

    


}