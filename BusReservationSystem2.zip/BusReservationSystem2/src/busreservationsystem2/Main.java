package busreservationsystem2;

import java.util.Scanner;

public class Main {
public static void main(String[] args) {
    BusReservationSystem2 b1 = new BusReservationSystem2();
    Scanner obj = new Scanner(System.in);

    while (true) {
        System.out.println("\n********************");
        System.out.println("SEAT RESERVATION SYSTEM");
        System.out.println("     ");
        System.out.println("1 - Initialize");
        System.out.println("2 - Register Customer");
        System.out.println("3 - Display Customer");
        System.out.println("4 - Sort by age Customer");
        System.out.println("5 - Register Bus");
        System.out.println("6 - Search Bus");
        System.out.println("7 - Reserve Seat");
        System.out.println("8 - Sort Reservations by Seat Number");
        System.out.println("9 - Display Reservations");
        System.out.println("10 - Cancel Reservation");
        System.out.println("11 - Find Shortest Path");
        System.out.println("0 - Exit");
        System.out.print("Enter Choice [1|2|3|4|5|6|7|8|9|10|0]: ");
        
        int choice = obj.nextInt();

        if (choice < 0 || choice > 10) {
            System.out.println("Invalid Choice");
        } else if (choice == 1) {
            b1.init();
        } else if (choice == 2) {
            b1.addCustomer();
        } else if (choice == 3) {
            b1.displayCustomers();
        } else if (choice == 4) {
            b1.sortCustomersByAge();
        }else if (choice == 5) {
            b1.addBus();
        } else if (choice == 6) {
            b1.searchBus();
        } else if (choice == 7) {
            b1.reserveSeat();
        } else if (choice == 8) {
            b1.sortReservationsBySeatNumber();
        } else if (choice == 9) {
            b1.displayReservations();
        } else if (choice == 10) {
            b1.cancelReservation();
        } else if (choice == 11) {
            System.out.println("Enter Start City: ");
            String startCity = obj.next();
            System.out.println("Enter End City: ");
            String endCity = obj.next();
            b1.findShortestPath(startCity, endCity);
        } else if (choice == 0) {
            break;
        }
    }
    System.out.println("***** END ******");
}
}